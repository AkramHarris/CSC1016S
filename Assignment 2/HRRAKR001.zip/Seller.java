// Akram Harris
// HRRAKR001
// 01/08/2024
public class Seller { // Creating a class "Seller"
   String ID; // Iniatilizing instance variables
   String Name;
   String Location;
   String Product;
   Money unit_price;
   int number_of_units;
   public static void main(String[] args) {
   
    }
}
